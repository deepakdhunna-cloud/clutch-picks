/// <reference types="nativewind/types" />

